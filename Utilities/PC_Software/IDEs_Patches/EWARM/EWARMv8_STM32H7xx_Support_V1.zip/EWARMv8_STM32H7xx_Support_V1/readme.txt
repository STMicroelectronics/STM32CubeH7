/******************** (C) COPYRIGHT 2019 STMicroelectronics ********************
* File Name          : readme.txt
* Author             : STMicroelectronics
* Description        : This file describes how to add STM32Hxx devices  support on EWARM 
********************************************************************************

Running the "EWARMv8_STM32H7xx_Support_V1.exe" adds the following:
  
1. Part numbers for  :
- Dual Core lines: STM32H745xx/H755xx/H747xx/H757xx
- Value line: STM32H750xx
- New single core line: STM32H742xx (with reduced internal RAM and without LTDC, JPEG peripherals)
- Legacy single core lines: STM32H743/H753


2. Automatic STM32H7 flash algorithm selection
3. SVD file 


How to use:
==========
* Before installing the files mentioned above, you need to have EWARM v8.xx 
or later installed. 
You can download EWARM from IAR web site @ www.iar.com
 
* Run "EWARMv8_STM32H7xx_Support_V1.exe"  at EWARM install directory.
EWARM Install Directory is set by default to "C:\Program Files\IAR Systems\Embedded Workbench \", 
please change it manually if you have EWARM installed at different location.

******************* (C) COPYRIGHT 2019 STMicroelectronics *****END OF FILE***************





	



