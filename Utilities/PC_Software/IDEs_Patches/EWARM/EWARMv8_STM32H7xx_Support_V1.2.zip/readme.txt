/******************** (C) COPYRIGHT 2020 STMicroelectronics **********************************
* File Name          : readme.txt
* Version            : V1.2
* Date               : 24/01/2020
* Author             : STMicroelectronics
* Description        : This file describes how to add STM32H7xx devices support on EWARM 
**********************************************************************************************

These packages contains the needed files to be installed in order to support STM32H7xx 
devices by EWARM8 and laters.

1. If you have already installed an STM32H7 patch before, you can remove it by running 
Uninstall_Patch.bat (run as administrator).

2. Running the "EWARMv8_STM32H7xx_Support_V1.2.exe" adds the following:
 - Dual Core lines: STM32H745xx/H755xx/H747xx/H757xx
 - Value line: STM32H750xx, STM32H7B0xx
 - Single core lines: STM32H743/H753/H742/H7A3/H7B3 
 - RPNs with SMPS:STM32H7Axx-Q/H7B3xx-Q  
 - RPNs without SMPS:STM32H7A/B3xx  
 - Adding support for new RPNs value line: STM32HB0xx
 - STM32H7B3I-EVAL dedicated connection with OSPI external loader support (revB)
 - STM32H7B3I-EVAL dedicated connection with FMC NOR external loader support 
 - STM32H7B3I_DISCO dedicated connection with OSPI external loader support
 - STM32H7B0x_DISCO dedicated connection with OSPI external loader support
 - STM32H7B0x_EVAL dedicated connection with OSPI external loader support
 - STM32H743x_EVAL  dedicated connection with QSPI and FMC-NOR external loader support
 - STM32H750x_DISCO dedicated connection with QSPI and MMC external loader support
 - Automatic STM32H7 flash algorithm selection
 - SVD files 

PS: when using external loader on EWARM, please unselect the verify from the debug menu

How to use:
==========
* Before installing the files mentioned above, you need to have EWARM v8.xx 
or later installed. 
You can download EWARM from IAR web site @ www.iar.com
 
* Run "EWARMv8_STM32H7xx_Support_V1.2.exe"  as administrator on EWARM install directory.
Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \", 

******************* (C) COPYRIGHT 2020 STMicroelectronics *****END OF FILE***************





	



