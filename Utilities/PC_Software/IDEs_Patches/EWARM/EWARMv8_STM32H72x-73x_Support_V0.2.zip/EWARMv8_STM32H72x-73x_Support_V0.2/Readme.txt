/******************** (C) COPYRIGHT 2020 STMicroelectronics ****************************************
* File Name          : readme.txt
* Author             : STMicroelectronics
* Version            : V0.2
* Date               : 10/04/2020
* Description        : This file describes how to add STM32H73x-72x devices  support for EWARM 
****************************************************************************************************

This package contains the needed files to be installed in order to support STM32H72x/3x
devices by EWARM v8 and laters.

1. If you have already installed an STM32H72x/3x patch before, you can remove it by running 
Uninstall_Patch.bat (run as administrator).

2. Running the "EWARMv8_STM32H72x-73x_Support_V0.2.exe" will add the following:
 - RPNs without CRYPTO:STM32H723xx/H733xx  
 - RPNs with CRYPTO:STM32H725xx/H735xx
 - STM32H730 Value Line  
 - Automatic STM32H72x/3x flash algorithm selection
 - STM32H735G-DK dedicated connection with OSPI external loader support
 - SVD file  

PS: when using external loader on EWARM, please unselect the verify from the debug menu

How to use:
==========
* Before installing the files mentioned above, you need to have EWARM v8.xx 
or later installed. 
You can download EWARM from IAR web site @ www.iar.com
 
* Run "EWARMv8_STM32H72x-73x_Support_V0.2.exe" as administrator on EWARM install directory.
Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \", 


******************* (C) COPYRIGHT 2020 STMicroelectronics *****END OF FILE***************





	



