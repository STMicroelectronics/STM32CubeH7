/******************** (C) COPYRIGHT 2020 STMicroelectronics ******************************************
* File Name          : readme.txt
* Version            : V2.4.3
* Date               : 26/03/2020
* Author             : STMicroelectronics
* Description        : This file describes how to add STM32H7xxx devices  support on MDK-ARM
******************************************************************************************************

These packages contains the needed files to be installed in order to support STM32H7xx 
devices by MDK-ARM v5.25 and laters.

  Running the "Keil.STM32H7xx_DFP.2.4.3.pack" adds the following:
  ==============================================================
1. Part numbers for  :
 - Dual Core lines: STM32H745xx/H755xx/H747xx/H757xx
 - Value line: STM32H750xx, STM32H7B0xx,STM32H730xx/H730xxQ
 - Single core lines: STM32H743/H753/H742/H723/H733/H735/H725
 - Product lines without SMPS: STM32H7A3xI/HB3xI (2MB) and STM32H7A3xG (1MB).
 - Product lines with SMPS: STM32H7A3xIxxQ/H7B3xIxxQ (2MB) and STM32H7A3xGxxQ (1MB). 

 - STM32H747I-Disco dedicated connection with QSPI external loader support
 - STM32H745I-Disco dedicated connection with QSPI external loader support
 - STM32H750B-Disco dedicated connection with QSPI/ MMC external loader support
 - STM32H743I-Eval  dedicated connection with QSPI/ FMC-NOR external loader support
 - STM32H7B3I-DISCO dedicated connection with OSPI external loader support
 - STM32H7B0-EVAL   dedicated connection with OSPI external loader support
 - STM32H7B0-DISCO  dedicated connection with OSPI external loader support 
 - STM32H7B3I-Eval (RevB)  dedicated connection with OSPI external loader support 
 - STM32H7B3I-EVAL dedicated connection with FMC NOR external loader support 
 - STM32H735-DISCO  dedicated connection with OSPI external loader support 

2. Automatic STM32H7 flash algorithm selection
3. SVD file 


 How to use:
 ===========
* Before installing the files mentioned above, you need to have MDK-ARM v5.25 or later installed. 
You can download pack from keil web site @ www.keil.com
 
* Double Clic on  "Keil.STM32H7xx_DFP.2.4.3.pack" in order to install this pack in the Keil install 
directory.


******************* (C) COPYRIGHT 2020 STMicroelectronics *****END OF FILE*******************************


	



